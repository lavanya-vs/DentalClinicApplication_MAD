package com.dentalclinic.app.activities;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.dentalclinic.app.R;
import com.dentalclinic.app.adapters.AppointmentAdapter;
import com.dentalclinic.app.database.DatabaseHelper;
import com.dentalclinic.app.models.Appointment;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.List;

public class ManageAppointmentsActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private AppointmentAdapter adapter;
    private DatabaseHelper db;
    private List<Appointment> appointments;
    private String userType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_appointments);

        db = new DatabaseHelper(this);
        userType = getIntent().getStringExtra("USER_TYPE");

        ImageView btnBack = findViewById(R.id.btnBack);
        FloatingActionButton fabAddAppointment = findViewById(R.id.fabAddAppointment);
        recyclerView = findViewById(R.id.recyclerViewAppointments);

        btnBack.setOnClickListener(v -> finish());

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        loadAppointments();

        fabAddAppointment.setOnClickListener(v -> showAddAppointmentDialog(null));
    }

    private void loadAppointments() {
        appointments = db.getAllAppointments();
        adapter = new AppointmentAdapter(appointments, this, userType, new AppointmentAdapter.AppointmentListener() {
            @Override
            public void onEdit(Appointment appointment) {
                showAddAppointmentDialog(appointment);
            }

            @Override
            public void onDelete(Appointment appointment) {
                db.deleteAppointment(appointment.getId());
                loadAppointments();
                Toast.makeText(ManageAppointmentsActivity.this, "Appointment deleted", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAccept(Appointment appointment) {
                appointment.setStatus("Accepted");
                db.updateAppointment(appointment);
                loadAppointments();
                Toast.makeText(ManageAppointmentsActivity.this, "Appointment accepted", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onReschedule(Appointment appointment) {
                showAddAppointmentDialog(appointment);
            }
        });
        recyclerView.setAdapter(adapter);
    }

    private void showAddAppointmentDialog(Appointment appointment) {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_add_appointment);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        EditText etPatientName = dialog.findViewById(R.id.etPatientName);
        EditText etDoctorName = dialog.findViewById(R.id.etDoctorName);
        EditText etDate = dialog.findViewById(R.id.etDate);
        EditText etTime = dialog.findViewById(R.id.etTime);
        Button btnSave = dialog.findViewById(R.id.btnSave);
        Button btnCancel = dialog.findViewById(R.id.btnCancel);

        if (appointment != null) {
            etPatientName.setText(appointment.getPatientName());
            etDoctorName.setText(appointment.getDoctorName());
            etDate.setText(appointment.getDate());
            etTime.setText(appointment.getTime());
        }

        btnSave.setOnClickListener(v -> {
            String patientName = etPatientName.getText().toString().trim();
            String doctorName = etDoctorName.getText().toString().trim();
            String date = etDate.getText().toString().trim();
            String time = etTime.getText().toString().trim();

            if (patientName.isEmpty() || doctorName.isEmpty() || date.isEmpty() || time.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            if (appointment == null) {
                Appointment newAppointment = new Appointment(0, patientName, doctorName, date, time, "Pending");
                db.addAppointment(newAppointment);
                Toast.makeText(this, "Appointment added", Toast.LENGTH_SHORT).show();
            } else {
                appointment.setPatientName(patientName);
                appointment.setDoctorName(doctorName);
                appointment.setDate(date);
                appointment.setTime(time);
                db.updateAppointment(appointment);
                Toast.makeText(this, "Appointment updated", Toast.LENGTH_SHORT).show();
            }

            loadAppointments();
            dialog.dismiss();
        });

        btnCancel.setOnClickListener(v -> dialog.dismiss());

        dialog.show();
    }
}