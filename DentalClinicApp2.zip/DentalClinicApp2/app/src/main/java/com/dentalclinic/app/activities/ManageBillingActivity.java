package com.dentalclinic.app.activities;

import android.app.Dialog;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.dentalclinic.app.R;
import com.dentalclinic.app.adapters.BillingAdapter;
import com.dentalclinic.app.database.DatabaseHelper;
import com.dentalclinic.app.models.Billing;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import java.util.List;

public class ManageBillingActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private BillingAdapter adapter;
    private DatabaseHelper db;
    private List<Billing> billings;
    private String userType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_billing);

        db = new DatabaseHelper(this);
        userType = getIntent().getStringExtra("USER_TYPE");

        ImageView btnBack = findViewById(R.id.btnBack);
        FloatingActionButton fabAddBilling = findViewById(R.id.fabAddBilling);
        recyclerView = findViewById(R.id.recyclerViewBilling);

        btnBack.setOnClickListener(v -> finish());

        // Only doctors can add billing
        if ("patient".equals(userType)) {
            fabAddBilling.setVisibility(View.GONE);
        }

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        loadBilling();

        fabAddBilling.setOnClickListener(v -> showAddBillingDialog(null));
    }

    private void loadBilling() {
        billings = db.getAllBilling();
        adapter = new BillingAdapter(billings, this, userType, new BillingAdapter.BillingListener() {
            @Override
            public void onEdit(Billing billing) {
                showAddBillingDialog(billing);
            }

            @Override
            public void onDelete(Billing billing) {
                db.deleteBilling(billing.getId());
                loadBilling();
                Toast.makeText(ManageBillingActivity.this, "Billing deleted", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onPay(Billing billing) {
                billing.setPaymentStatus("Paid");
                db.updateBilling(billing);
                loadBilling();
                Toast.makeText(ManageBillingActivity.this, "Payment successful", Toast.LENGTH_SHORT).show();
            }
        });
        recyclerView.setAdapter(adapter);
    }

    private void showAddBillingDialog(Billing billing) {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_add_billing);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        EditText etPatientName = dialog.findViewById(R.id.etPatientName);
        EditText etDoctorName = dialog.findViewById(R.id.etDoctorName);
        EditText etAmount = dialog.findViewById(R.id.etAmount);
        EditText etDate = dialog.findViewById(R.id.etDate);
        Button btnSave = dialog.findViewById(R.id.btnSave);
        Button btnCancel = dialog.findViewById(R.id.btnCancel);

        if (billing != null) {
            etPatientName.setText(billing.getPatientName());
            etDoctorName.setText(billing.getDoctorName());
            etAmount.setText(String.valueOf(billing.getAmount()));
            etDate.setText(billing.getDate());
        }

        btnSave.setOnClickListener(v -> {
            String patientName = etPatientName.getText().toString().trim();
            String doctorName = etDoctorName.getText().toString().trim();
            String amountStr = etAmount.getText().toString().trim();
            String date = etDate.getText().toString().trim();

            if (patientName.isEmpty() || doctorName.isEmpty() || amountStr.isEmpty() || date.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            double amount = Double.parseDouble(amountStr);

            if (billing == null) {
                Billing newBilling = new Billing(0, patientName, doctorName, amount, date, "Unpaid");
                db.addBilling(newBilling);
                Toast.makeText(this, "Billing added", Toast.LENGTH_SHORT).show();
            } else {
                billing.setPatientName(patientName);
                billing.setDoctorName(doctorName);
                billing.setAmount(amount);
                billing.setDate(date);
                db.updateBilling(billing);
                Toast.makeText(this, "Billing updated", Toast.LENGTH_SHORT).show();
            }

            loadBilling();
            dialog.dismiss();
        });

        btnCancel.setOnClickListener(v -> dialog.dismiss());

        dialog.show();
    }

    public static Bitmap generateQRCode(String content) {
        QRCodeWriter writer = new QRCodeWriter();
        try {
            BitMatrix bitMatrix = writer.encode(content, BarcodeFormat.QR_CODE, 512, 512);
            int width = bitMatrix.getWidth();
            int height = bitMatrix.getHeight();
            Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565);
            for (int x = 0; x < width; x++) {
                for (int y = 0; y < height; y++) {
                    bitmap.setPixel(x, y, bitMatrix.get(x, y) ? Color.BLACK : Color.WHITE);
                }
            }
            return bitmap;
        } catch (WriterException e) {
            e.printStackTrace();
            return null;
        }
    }
}